//
//  WMDetailViewController.h
//  StickyExample
//
//  Created by Tpphha on 2017/7/22.
//  Copyright © 2017年 Tpphha. All rights reserved.
//

#import "WMPageController.h"
#import "WMStickyPageViewController.h"

@interface WMDetailViewController : WMPageController <WMStickyPageViewControllerDelegate>

@end
