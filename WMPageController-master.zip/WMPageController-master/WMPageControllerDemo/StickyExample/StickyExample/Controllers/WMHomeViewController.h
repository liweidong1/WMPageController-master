//
//  WMHomeViewController.h
//  Demo
//
//  Created by Mark on 16/7/25.
//  Copyright © 2016年 Wecan Studio. All rights reserved.
//

#import "WMStickyPageViewController.h"

static CGFloat const kWMHeaderViewHeight = 200;
static CGFloat const kNavigationBarHeight = 64;
@interface WMHomeViewController : WMStickyPageViewController 

@end
