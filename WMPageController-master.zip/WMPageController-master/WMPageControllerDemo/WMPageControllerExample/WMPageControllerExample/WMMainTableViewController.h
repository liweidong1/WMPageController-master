//
//  WMMainTableViewController.h
//  WMPageControllerExample
//
//  Created by Mark on 2017/6/21.
//  Copyright © 2017年 Mark. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WMMainTableViewController : UITableViewController

@end
