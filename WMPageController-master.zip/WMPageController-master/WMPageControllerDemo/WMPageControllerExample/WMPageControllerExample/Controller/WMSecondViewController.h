//
//  WMSecondViewController.h
//  WMPageController
//
//  Created by Mark on 16/2/27.
//  Copyright © 2016年 yq. All rights reserved.
//

#import <UIKit/UIKit.h>
@class WMPageController;

@interface WMSecondViewController : UIViewController
@property (nonatomic, strong) WMPageController *pageController;
@end
